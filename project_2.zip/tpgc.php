<?php session_start();?>
<html>
<link rel="stylesheet" href="generate.css">
<body>
<div class="background"></div>
</body>
</html>
<?php
if($_SESSION['expcommlogin'] != "1")
{
  // session_destroy();
  echo"<script> window.open('login.php','_self');</script>";
}
else {
  # code...

include"header.php";
include 'dbconnect.php';

if(isset($_POST['milk30']))
{

$milk30 = mysqli_real_escape_string($link, $_POST['milk30']);
// echo"$tpgc";
$query = "UPDATE billfactors  SET milk30='$milk30' where id=1";
mysqli_query($link,$query);
}
}
// echo 'done';

?>



<HTML>
<head>
<title>Total Permanent Guest Charge</title>

</head>
<body>

<form action="generate.php" method="post">

<font id="establishment" color="white">Total Permanent Guest Charge</font><br><br>
<input type="number" step="any" min="0"  name="tpgc" required><br><br>
<input id="submit" type="submit" name="submit" value="Submit">

</form>

</body>
</HTML>
