<?php
include"dbconnect2.php";
$query1 = "delete from dummypurchases";
mysql_query($query1);
$query2 = "select * from purchases";
$r = mysql_query($query2);
if(mysql_num_rows($r)!=0)
{
  while($row=mysql_fetch_array($r))
  {
  $query3 = "insert into dummypurchases (DATE,EXPENDITURE_PAID,EXPENDITURE_UNPAID,ESTABLISHMENT_PAID,ESTABLISHMENT_UNPAID)
  values('$row['Date']','$row['Expenditure_Paid']','$row['Expenditure_Unpaid']','$row['Establishment_Paid']','$row['Establishment_Unpaid']')";
  mysql_query($query3);
}
}



 ?>
