<?php
include"dbconnect2.php";
include"header.php";
$query = "select * from commpass";
$date = date("Y-m-d");
 echo"$date";
$r = mysql_query($query);
if(mysql_num_rows($r)!=0)
{
while($row = mysql_fetch_array($r))
{
    if($row['LAST_DATE']<$date)
    {
      $lday = $row['LAST_DATE'];
      if($lday<$date)
      {
        echo"hi";
      }
      echo"$lday";
      $query1 = "update commpass set BOOLEAN='0' where '$lday'<'$date'";
      if(mysql_query($query1))
      {
        echo"Boolean Change Successfully";
        $flag=1;
      }
      else {
        echo"Error";
      }
    }
    if($flag==1)
    break;
}


}
?>
