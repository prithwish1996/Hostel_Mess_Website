<?php session_start();
?>
<!doctype html>
<html lang="en">
<link rel="stylesheet" href="viewjoin.css">
<body>
  <div class="background"></div>
  <strong>  <a href="optioncomm.php">Home/</a><a href="joinnview.php">MessJoin/</a><a href="viewjoin.php">ViewJoin</a></strong>
  </html>
  <?php
  if($_SESSION['prcommlogin'] != "1")
  {
    // session_destroy();
    echo"<script> window.open('login.php','_self');</script>";
  }
  else {

  include "header.php";
  include"dbconnect2.php";
  //session_start();
  // if(!isset($_SESSION['fromPurchases'])){
  //    //send them back
  //    header("Location: Adminlogin.php");
  // }
      $query1 = "select * from reduction";
      $query = "select ID from messjoin";
      $sql1 = mysql_query($query1);
      $sql = mysql_query($query);
      $mj = array();
      $re = array();
      $ac = array();
      $jid = array();
      $i=0;
      $j=0;
      $r=0;
      $s=0;
      // if((mysql_num_rows($sql)==0))
      // {
      //   echo"<br>";
      //   echo"<h2>No data Found in Normal Join</h2>";
      // }

        // echo "<br><br><table border='1'><tr><th>NORMAL JOIN ID's</th></tr>";
      while($row= mysql_fetch_array($sql))
      {

        $mj[$i++]=$row['ID'];
      }
      while($row=mysql_fetch_array($sql1))
      {

        $re[$j]=$row['ID'];
        $ac[$j]=$row['active'];
        ++$j;
      }
      $k=0;
      for($r=0; $r<$i; $r++)
      {
        $flag=0;
        for($s=0; $s<$j; $s++)
        {
          if($mj[$r]==$re[$s])
          {
            $flag=1;
            if($ac[$s]==0)
            {
              $jid[$k++]=$mj[$r];
              break;
            }
          else {
            break;
          }

          }
          else {
            $flag=0;
          }

        }
        if($flag==0)
        $jid[$k++]=$mj[$r];
      }
      $r=0;

      echo "<br><br><table id='nj' border='4'><tr><th><h3>NORMAL JOIN ID's</h3></th></tr>";
    while($r<$k)
    {

      echo "<tr>";
      echo "<td><p id='jid'>" . $jid[$r] . "</p></td>";
      echo "</tr>";
      ++$r;
    }
echo"</table>";

    // echo"<br><br>";
    $query = "select ID from latejoin";
    $sql = mysql_query($query);

    // if((mysql_num_rows($sql)==0))
    // {
    //   echo"<br>";
    //   echo"<h2>No data Found in Late Join</h2>";
    // }
    // else
      echo "<table id='lj' border='4'><tr><th><h3>LATE JOIN ID's</h3></th></tr>";
    while($row= mysql_fetch_array($sql))
    {

      echo "<tr>";
      echo "<td><p id='row'>" . $row[0] . "</p></td>";
      echo "</tr>";
    }
    echo "</table>";


}



?>
