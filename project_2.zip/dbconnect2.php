<?php
mysql_connect("localhost","root","")or die("OOps Unable to connect to the database");
mysql_select_db("hostel") or die("No Database Found");
date_default_timezone_set('Asia/Kolkata');
?>
