<?php include"header.php";
?>
<html>
<head>
  <link rel="stylesheet" href="expcomm.css">
</head>
<body>
  <div class="background"></div>
  <br><br><br><br><br>
  <h2><p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspPRITHWISH DASGUPTA -------- +919496683469 E-mail----> prithwish.dsgpt@gmail.com (Languages Known : English, Hindi)</p></h2><br><br><br><br><br>
  <h2><p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspNELWIN JACOB -------- +918281923829 E-mail----> nelwin999@gmail.com (Languages Known : English, Malayalam, Hindi)</p></h2><br><br><br><br><br>
<h2><p>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspPRASHANT KUMAR -------- +919497577836 E-mail----> pk611886@gmail.com (Languages Known : English, Hindi)</p></h2><br><br><br><br><br>
</body>
</html>
