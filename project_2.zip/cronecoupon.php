<?php
include"dbconnect2.php";
$query1 = "delete from latecoupon";
$query2 = "delete from coupon";
if(mysql_query($query1) and mysql_query($query2))
{
  echo"Deleted Successfully from Coupon";
}
else {
  echo"error";
}
 ?>
