<?php session_start();
?>
<HTML>
<head>
<title>Mess Join</title>
<link rel="stylesheet" href="join3.css">
</head>
<body>
<div class="background"></div>
<strong>  <a href="optioncomm.php">Home/</a><a href="joinnview.php">MessJoin/</a><a href="join3.php">NormalJoin</a></strong>
<h2 align="center"><b><u>MESS JOIN</u></b></h2>

<form action="join3.php" method="post">
<font color="white" id="f">
Mess ID
<input type="text" name="MessID">
<br><br>
Menu

<select name="menu">
  <option value="VEG">Veg</option>
  <option value="VE">Veg+Egg</option>
  <option value="VF">Veg+Fish</option>
  <option value="VFC">Veg+FishCurry</option>
  <option value="VFF">Veg+FishFry</option>
  <option value="VC">Veg+Chicken</option>
  <option value="NV">Non.Veg</option>
  <option value="NVE">Non.Veg-Egg</option>
  <option value="NVF">Non.Veg-Fish</option>
  <option value="NVFC">Non.Veg-FishCurry</option>
  <option value="NVFF">Non.Veg-FishFry</option>
  <option value="NVC">Non.Veg-Chicken</option>
</select> <br> <br>
</font>
<input id="submit" type="submit" onclick="return confirm('Are you sure you want to Add this ID in JOIN LIST?')" name="submit" value="Submit">
</form>

</body>
</HTML>


<?php
if($_SESSION['prcommlogin'] != "1")
{
  // session_destroy();
  echo"<script> window.open('login.php','_self');</script>";
}
else {

include"header.php";
 $errormsg="ID ENTERED ALREADY JOINED!";
 $errormsg2="ID NOT FOUND";
 $successmsg="ID SUCCESSFULLY JOINED";
 if(isset($_POST['submit']))
 {

  include 'dbconnect.php';
  $userchecker=0;
  $flag=1;
  $flagforjoin=0;
  $mid = mysqli_real_escape_string($link, $_POST['MessID']);
  $menu = mysqli_real_escape_string($link, $_POST['menu']);
  $day=date("d");
  $total=date("t");
  $effective=($total-$day);



  $query2="SELECT ID from users";    //first check with user db
  $users=mysqli_query($link,$query2);
  while($rowuser=mysqli_fetch_array($users))
  {
    if(($rowuser[0]==$mid))
    {
     $userchecker=1; //found in user table

     $query="SELECT * from messjoin";   //check if already joined
     $search=mysqli_query($link,$query);

     while ($row=mysqli_fetch_row($search))
     {
      if(($row[0]==$mid)&&($row[3]==1))  //found in messjoin but active
      {
        echo ' <script type="text/javascript">
          alert("'.$errormsg.'");
         </script>
        ';

       break;  //end searching in messjoin
      }
      else if(($row[0]==$mid)&&($row[3]==0)) //found in messjoin but inactive
      {
        $sql="UPDATE messjoin set active=1 where id='$mid'";
        if( mysqli_query($link,$sql))
        {
         echo ' <script type="text/javascript">
           alert("'.$successmsg.'");
          </script>
         ';
        }

        $query_for_reduction="SELECT * from reduction";   //code for updating reduction db when join happens
        $reduced=mysqli_query($link,$query_for_reduction);
        while($rowred=mysqli_fetch_row($reduced))
        {
         if(($rowred[0]==$mid)&&($rowred[1]<3)&&($rowred[2]==1))
         {
          $query3="UPDATE reduction SET count=0,active=0 where ID='$rowred[0]'";
          mysqli_query($link,$query3);
         }
         else if (($rowred[0]==$mid)&&($rowred[1]>=3)&&($rowred[2]==1))
         {
          $query4="UPDATE reduction SET count=0,active=0,total=total+'$rowred[1]' where ID='$rowred[0]'";
          mysqli_query($link,$query4);
         }
        }


        break; //end searching in messjoin
      }
      else
      {
        $sql = "INSERT INTO messjoin (ID, menu,effective,active) VALUES ('$mid', '$menu','$effective',1)";
        if(mysqli_query($link, $sql))
        {
         echo ' <script type="text/javascript">
            alert("'.$successmsg.'");
           </script>
         ';
         }

         $query_for_reduction="SELECT * from reduction";   //code for updating reduction db when join happens
         $reduced=mysqli_query($link,$query_for_reduction);
         while($rowred=mysqli_fetch_row($reduced))
         {
          if(($rowred[0]==$mid)&&($rowred[1]<3)&&($rowred[2]==1))
          {
           $query3="UPDATE reduction SET count=0,active=0 where ID='$rowred[0]'";
           mysqli_query($link,$query3);
          }
          else if (($rowred[0]==$mid)&&($rowred[1]>=3)&&($rowred[2]==1))
          {
           $query4="UPDATE reduction SET count=0,active=0,total=total+'$rowred[1]' where ID='$rowred[0]'";
           mysqli_query($link,$query4);
          }
         }


      }


     }
   }
 }

 if($userchecker==0) //not found in user table
 {
  echo ' <script type="text/javascript">
     alert("'.$errormsg2.'");
    </script>
  ';
  }

}
}
?>
