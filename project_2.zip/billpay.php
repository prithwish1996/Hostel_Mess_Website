<?php session_start();
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="billpay.css">


</head>

<body>
  <strong>
    <div class="background"></div>
<?php
if($_SESSION['seclogin'] != "1")
{
  // session_destroy();
  echo"<script> window.open('login.php','_self');</script>";
}
else
{
include "header.php";
  include"dbconnect2.php";

$name=101;$roomno=101;$bill=101;$amountpaid=101;$submit=101;
echo'<form id="billpay" action="billpay.php" method="post">';
echo"<table>";
  echo"<tr>";
    echo"<th>ID</th>";
    echo"<th>NAME</th>";
      echo"<th>ROOM_NO</th>";
        echo"<th>BILL</th>";
          echo"<th>AMOUNT PAID</th>";
            echo"<th>SUBMIT</th>";
     echo"</tr>";
       $query0 = "select ID from users";
       $sql0 = mysql_query($query0);
$last=mysql_num_rows( $sql0);
$last2=$last+100;
for($i=101;$i<=$last2;$i++)
{


    $query = "select * from users where ID='$i'";
  $sql = mysql_query($query);
  $row=mysql_fetch_array($sql);
  echo"<tr>";
      echo "<td>" . $row['ID'] . "</td>";
      echo "<td>" . $row['NAME'] . "</td>";
      echo "<td>" . $row['ROOM_NO'] . "</td>";
      echo "<td>" . $row['total'] . "</td>";

      echo'<td> <input type="number" name="<?php $amountpaid ?>" value="<?php echo @$amtpaid;?>"></td>';
      echo'<td> <input type="submit" name="<?php $submit ?>" ></td>';
          echo"</tr>";

        $name++;$roomno++;$bill++;$amountpaid++;$submit++;
}



echo"</table>";
echo"</form>";






}
  ?>

</body>

</html>
<?php
if(isset($_POST['$submit']))
{
  $amountpaid = $_POST['$amountpaid'];
  $total = $_POST['bill'];
  $id = $_POST['ID'];
  $rem = $total - $amountpaid;
  $query1 = "update users set due = '$rem' where ID='$id'";
  $query2 = "update users set fine = '0' where ID='$id'";
  $query3 = "update users set messbill='0' where ID='$id'";
  mysql_query($query1);
  mysql_query($query2);
  mysql_query($query3);

}

 ?>
