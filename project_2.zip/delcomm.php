<?php session_start();
?>
<!doctype html>
<html lang="en">
<link rel="stylesheet" href="dues.css">
<body>
  <div class="background"></div>
  </html>
  <?php
  if($_SESSION['seclogin'] != "1")
  {
    // session_destroy();
    echo"<script> window.open('login.php','_self');</script>";
  }
  else
  {
  include "header.php";
  include"dbconnect2.php";
 $query = "delete from commpass where BOOLEAN='0'";

  if(mysql_query($query))
  {
    echo"<h2><br><br>&nbsp&nbsp&nbspPrevious Committee Has Been Successfully Deleted!!!!</h2>";
  }
  else {
    echo"<h2><br><br>&nbsp&nbsp&nbspNo Previous Committee exists</h2>";
  }
}
  ?>
